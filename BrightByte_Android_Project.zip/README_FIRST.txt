BRIGHTBYTE ANDROID PROJECT — IMPORTANT

What is included:
- BrightByte app content (quiz, riddles, facts, jokes and local score)
- A basic Android WebView wrapper
- Android project configuration
- A GitHub Actions workflow that can build a DEBUG APK in the cloud

What is NOT included yet:
- Google AdMob SDK / ad units (do not add ads until the app is tested and policy-compliant)
- A release-signed Android App Bundle (AAB)
- Google Play Console publication

HOW TO GET A TEST APK USING GITHUB (can be done from a phone, but the screens are easier in desktop mode):
1. Create a NEW public or private GitHub repository named BrightByte.
2. Upload the CONTENTS of this ZIP into the repository (not the ZIP file itself). Keep the .github folder.
3. Open the repository's Actions tab.
4. If GitHub asks, enable Actions for the repository.
5. Choose "Build BrightByte Android APK" on the left, tap "Run workflow".
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to Artifacts, and download "BrightByte-debug-APK".
8. Extract the downloaded artifact ZIP; install app-debug.apk on your Android phone. Android may ask you to allow installation from that browser/file manager.

NOTES:
- This debug APK is for testing on your own phone. It is NOT ready for Google Play.
- For Play publication we must create a release signing key, keep it private and backed up,
  configure a signed release build, and produce an AAB.
- Never share your keystore file or passwords in chat or on GitHub.
- The application currently contains no advertisements and does not yet connect to AdMob.
- The Android application ID is com.brightbyte.app. We should keep it stable once publishing work starts.
